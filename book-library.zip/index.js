const express = require('express');
const cors = require('cors');
const app = express();
const db = require('./src/models');
const bodyParser = require('body-parser');
const loginRouter = require('./src/routes/login.routes');
const authorRouter = require('./src/routes/author.routes');
const authorGetRouter = require('./src/routes/author.get.routes');
const bookRouter = require('./src/routes/book.routes');
const reviewRouter = require('./src/routes/review.routes');

const reset = require('./src/setup');
const { handleError } = require('./src/middleware/customError');
const { default: axios } = require('axios');
const isBetweenTwoDate = require('./src/utils/isBetweenTwoDate');
const getNowDate = require('./src/utils/getNowDate');
const { CustomError, TypeError } = require('./src/models/customError.model');
require('dotenv').config();

var corsOptions = {
  origin: '*',
};
app.use(cors(corsOptions));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('./images'));
app.use(express.json());

app.use(express.urlencoded({ extended: true }));

db.sequelize.sync().then((se) => {
  reset(db);
});

app.use('/v1', loginRouter);
app.use('/v1', authorGetRouter);
app.use('/v202', authorRouter);
app.use('/v391', bookRouter);
app.use('/v485', reviewRouter);
app.use(function (req, res, next) {
  throw new CustomError(404, TypeError.PATH_NOT_FOUND);
});
app.use(handleError);

const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
