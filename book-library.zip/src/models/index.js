const Sequelize = require('sequelize');
const reset = require('../setup');
const setupRelationship = require('../setupRelationship');
require('dotenv').config();

// const config = {
//   host: 'us-cdbr-east-05.cleardb.net',
//   user: 'b7985b6506dae5',
//   pass: 'd0e8a0ca',
//   dbName: 'heroku_ab0be7b25b16bc0',
// };

const config = {
  host: 'localhost',
  user: 'apiquest',
  pass: '4XJ-xRB-h2D-SyG',
  dbName: 'apiquest',
};

const sequelize = new Sequelize(config.dbName, config.user, config.pass, {
  host: config.host,
  dialect: 'mysql',
  pool: {
    max: 10,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
  logging: false,
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

//MODELS
db.logins = require('./login.model')(sequelize, Sequelize);
db.books = require('./book.model')(sequelize, Sequelize);
db.reviews = require('./review.model')(sequelize, Sequelize);
db.authors = require('./author.model')(sequelize, Sequelize);

setupRelationship(db);

module.exports = db;
