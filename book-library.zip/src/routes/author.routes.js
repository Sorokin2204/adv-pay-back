const Router = require('express');
const authorController = require('../controller/author.controller');
const router = new Router();
const auth = require('../middleware/auth');
const { errorWrapper } = require('../middleware/customError');
const validate = require('../middleware/validate');
const { authorValidation, authorByIdValidation, authorUpdateAllValidation, authorUpdateValidation, authorDeleteValidation } = require('../validation/author.validation');

router.post('/author/add', errorWrapper(validate(authorValidation)), errorWrapper(auth), errorWrapper(authorController.createAuthor));

router.patch('/author/:id', errorWrapper(validate(authorUpdateValidation)), errorWrapper(auth), errorWrapper(authorController.updateAuthor));

router.delete('/author/:id', errorWrapper(validate(authorDeleteValidation)), errorWrapper(auth), errorWrapper(authorController.deleteAuthor));
module.exports = router;
