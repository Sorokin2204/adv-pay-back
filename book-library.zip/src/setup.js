function reset(db) {
  // db.logins.bulkCreate([{ login: 'user', password: '$04$p69et5hvCyw3k7HsiWX0CexU/nG15Ds3ALKITH/D01tVxXMcZQ7xW' }]);
}

module.exports = reset;
