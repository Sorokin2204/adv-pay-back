function isFutureDate(idate) {
  var today = new Date().getTime(),
    idate = idate.split('/');

  idate = new Date(idate[2], idate[1] - 1, idate[0]).getTime();
  return today - idate < 0 ? true : false;
}
module.exports = isFutureDate;
